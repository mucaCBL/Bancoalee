package com.controle.notebooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotebooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
