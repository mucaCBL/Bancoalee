package com.controle.notebooks.Service;

import com.controle.notebooks.Model.M_Usuario;
import com.controle.notebooks.Repository.R_Usuario;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.sql.Date;


@Service
public class S_Usuario {
    private static R_Usuario r_usuario;

    public S_Usuario(R_Usuario r_usuario) {
        this.r_usuario =  r_usuario;
    }

    public static M_Usuario verificaLogin(String nome, String senha){

        if(S_Generico.textoEstaVazio(nome)){
            return null;
        }else if(S_Generico.textoEstaVazio(senha)){
            return null;
        }
        return r_usuario.buscarPorNomeSenha(nome,
                senha);
    }

    public static String cadastrarUsuario(String nome, Date data_nascimento, long CPF, long RG, long numero_celular, String email, String CEP, String cidade, String estado, String senha){
        boolean podeSalvar = true;
        String mensagem = "";

        if(S_Generico.textoEstaVazio(nome)){
            podeSalvar = false;
            mensagem += "O nome precisa ser preenchido!";
        }
        if(!S_Generico.validarEmail(String.valueOf(data_nascimento))){
            podeSalvar = false;
            mensagem += "e-Mail inválido!";
        }

        if(podeSalvar){
            M_Usuario m_usuario = new M_Usuario();

            try{
                r_usuario.save(m_usuario);
                mensagem += "Usuário cadastrado com sucesso!";
            }catch (DataIntegrityViolationException e){
                mensagem += "Falha ao cadastrar usuário";
            }
        }
        return mensagem;
    }

    public static void updateTeste(M_Usuario usuario){
        usuario.setSenha("1234");
        r_usuario.save(usuario);
    }

    public static void updateSenhaById(M_Usuario usuario){
        usuario.setSenha("4321");
        r_usuario.atualizaSenhaUsuarioPorId(usuario.getSenha(), usuario.getId());
    }


}
